import { useState } from "react";
import { data } from "./utils/data";
import { RecipeListPage } from "./pages/RecipeListPage";
import { RecipePage } from "./pages/RecipePage";

export const App = () => {
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  return (
    <div className="App">
      {selectedRecipe ? (
        <RecipePage
          recipe={selectedRecipe}
          clickFn={() => setSelectedRecipe(null)}
        />
      ) : (
        <RecipeListPage data={data} clickFn={setSelectedRecipe} />
      )}
    </div>
  );
};

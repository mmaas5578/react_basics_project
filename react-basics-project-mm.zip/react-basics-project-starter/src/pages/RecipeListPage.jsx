import {
  Box,
  Center,
  Container,
  Heading,
  Image,
  Input,
  SimpleGrid,
  Text,
  UnorderedList,
  ListItem,
  Tag,
  TagLabel,
} from "@chakra-ui/react";
import { useState } from "react";

export const RecipeListPage = ({ data, clickFn }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredRecipes = data.hits.filter((item) => {
    const recipe = item.recipe;
    const lowerSearch = searchTerm.toLowerCase();

    const matchesLabel = recipe.label.toLowerCase().includes(lowerSearch);
    const matchesHealth = recipe.healthLabels.some((label) =>
      label.toLowerCase().includes(lowerSearch)
    );

    return matchesLabel || matchesHealth;
  });

  return (
    <Container
      bg="orange.200"
      maxW="container.xl"
      py={{ base: 4, md: 8 }}
      display="flex"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
    >
      <Center mb={8}>
        <Heading fontSize={{ base: "2xl", md: "3xl" }}>
          Delicious Recipes App
        </Heading>
      </Center>

      <Input
        placeholder="Search by name or health label"
        value={searchTerm}
        bg="orange.50"
        onChange={(event) => setSearchTerm(event.target.value)}
        mb={8}
        maxW="md"
        textAlign="center"
      />

      <SimpleGrid columns={{ base: 1, sm: 2, md: 3, lg: 4 }} spacing={6}>
        {filteredRecipes.length > 0 ? (
          filteredRecipes.map((item, index) => {
            const recipe = item.recipe;
            const { label, image, dietLabels, cautions, mealType, dishType } =
              recipe;

            return (
              <Box
                bg="orange.50"
                key={index}
                p={4}
                borderWidth="1px"
                borderRadius="lg"
                shadow="md"
                _hover={{ cursor: "pointer", bg: "gray.50" }}
                onClick={() => clickFn(recipe)}
                display="flex"
                flexDirection="column"
                justifyContent="space-between"
                height="450px"
              >
                <Image
                  src={image}
                  alt={label}
                  w="100%"
                  h="200px"
                  objectFit="cover"
                  borderRadius="md"
                  mb={4}
                />

                <Heading
                  size="md"
                  mb={2}
                  textAlign="center"
                  wordBreak="break-word"
                  whiteSpace="normal"
                >
                  {label}
                </Heading>
                <Text
                  textTransform="uppercase"
                  mt={2}
                  fontSize="sm"
                  color={"grey"}
                  textAlign="center"
                >
                  {mealType?.join(", ") || "N/A"}
                </Text>

                {recipe.healthLabels.some(
                  (label) => label === "Vegan" || label === "Vegetarian"
                ) && (
                  <Box
                    mt={2}
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                  >
                    <UnorderedList
                      display="flex"
                      flexWrap="wrap"
                      gap={2}
                      listStyleType="none"
                      m={0}
                      p={0}
                      justifyContent="center"
                    >
                      {recipe.healthLabels
                        .filter(
                          (label) => label === "Vegan" || label === "Vegetarian"
                        )
                        .map((label, i) => (
                          <ListItem key={i}>
                            <Tag colorScheme="green">
                              <TagLabel>{label}</TagLabel>
                            </Tag>
                          </ListItem>
                        ))}
                    </UnorderedList>
                  </Box>
                )}

                {dietLabels.length > 0 && (
                  <Box
                    mt={2}
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                  >
                    <UnorderedList
                      display="flex"
                      flexWrap="wrap"
                      gap={2}
                      listStyleType="none"
                      m={0}
                      p={0}
                      justifyContent="center"
                    >
                      {dietLabels.map((diet, i) => (
                        <ListItem key={i}>
                          <Tag colorScheme="teal">
                            <TagLabel>{diet}</TagLabel>
                          </Tag>
                        </ListItem>
                      ))}
                    </UnorderedList>
                  </Box>
                )}
                <Text fontSize="sm" mt={2} textAlign="center">
                  Dish:{" "}
                  {dishType
                    ?.map(
                      (dish) => dish.charAt(0).toUpperCase() + dish.slice(1)
                    )
                    .join(", ") || "N/A"}
                </Text>

                {cautions.length > 0 && (
                  <Box
                    mt={2}
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                  >
                    <Text fontSize="sm" textAlign="center">
                      Cautions:
                    </Text>
                    <UnorderedList
                      display="flex"
                      flexWrap="wrap"
                      gap={2}
                      listStyleType="none"
                      m={0}
                      p={0}
                      justifyContent="center"
                    >
                      {cautions.map((caution, i) => (
                        <ListItem key={i}>
                          <Tag colorScheme="red">
                            <TagLabel>{caution}</TagLabel>
                          </Tag>
                        </ListItem>
                      ))}
                    </UnorderedList>
                  </Box>
                )}
              </Box>
            );
          })
        ) : (
          <Text>No recipes found</Text>
        )}
      </SimpleGrid>
    </Container>
  );
};

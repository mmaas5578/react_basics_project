import {
  Box,
  Button,
  Card,
  CardBody,
  Container,
  Grid,
  GridItem,
  Heading,
  Image,
  ListItem,
  Tag,
  TagLabel,
  Text,
  UnorderedList,
} from "@chakra-ui/react";
import { ArrowBackIcon } from "@chakra-ui/icons";

export const RecipePage = ({ recipe, clickFn }) => {
  const {
    label,
    mealType,
    totalTime,
    ingredientLines,
    totalNutrients,
    dietLabels,
    healthLabels,
    cautions,
    image,
    dishType,
    yield: servings,
  } = recipe;

  return (
    <Box bg="orange.100" minH="100vh" py={8}>
      <Container maxW="container.md" px={4}>
        <Button
          leftIcon={<ArrowBackIcon />}
          mb={6}
          bg="orange.300"
          color="white"
          _hover={{ bg: "orange.400" }}
          onClick={() => clickFn(null)}
        >
          Back to Recipe List
        </Button>

        <Card bg="orange.50" boxShadow="lg">
          <Image
            src={image}
            alt={label}
            width="100%"
            maxH="400px"
            objectFit="cover"
            borderTopRadius="lg"
          />

          <CardBody>
            <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={8}>
              <GridItem>
                <Box mb={4}>
                  <Text textTransform="uppercase" color={"grey"}>
                    {mealType?.join(", ") || "N/A"}
                  </Text>
                </Box>

                <Heading mb={6} textAlign="left">
                  {label}
                </Heading>

                <Box mb={4}>
                  <Text>
                    {" "}
                    Total cooking time:{" "}
                    {totalTime ? `${totalTime} Minutes` : "N/A"}
                  </Text>
                </Box>

                <Box mb={4}>
                  <Text>{servings ? `${servings} servings` : "N/A"}</Text>
                </Box>

                <Box mb={4} textAlign="left">
                  Dish:{" "}
                  {dishType
                    ?.map(
                      (dish) => dish.charAt(0).toUpperCase() + dish.slice(1)
                    )
                    .join(", ") || "N/A"}
                </Box>

                <Box mb={4}>
                  <Text fontSize={"2xl"}>Ingredients:</Text>
                  <UnorderedList spacing={2} pl={4} listStyleType="none">
                    {ingredientLines?.map((ingredient, index) => (
                      <ListItem key={index}>{ingredient}</ListItem>
                    ))}
                  </UnorderedList>
                </Box>
              </GridItem>

              <GridItem>
                {healthLabels?.length > 0 && (
                  <Box mb={4}>
                    <Text mb={2}>Health Labels:</Text>
                    <UnorderedList
                      display="flex"
                      flexWrap="wrap"
                      gap={2}
                      m={0}
                      p={0}
                      listStyleType="none"
                    >
                      {healthLabels.map((label, index) => (
                        <ListItem key={index}>
                          <Tag colorScheme="green">
                            <TagLabel textTransform="uppercase">
                              {label}
                            </TagLabel>
                          </Tag>
                        </ListItem>
                      ))}
                    </UnorderedList>
                  </Box>
                )}

                {dietLabels?.length > 0 && (
                  <Box mb={4}>
                    <Text mb={2}>Diet Labels:</Text>
                    <UnorderedList
                      display="flex"
                      flexWrap="wrap"
                      gap={2}
                      m={0}
                      p={0}
                      listStyleType="none"
                    >
                      {dietLabels.map((diet, index) => (
                        <ListItem key={index}>
                          <Tag colorScheme="teal">
                            <TagLabel textTransform="uppercase">
                              {diet}
                            </TagLabel>
                          </Tag>
                        </ListItem>
                      ))}
                    </UnorderedList>
                  </Box>
                )}

                {cautions?.length > 0 && (
                  <Box mb={4}>
                    <Text mb={2}>Cautions:</Text>
                    <UnorderedList
                      display="flex"
                      flexWrap="wrap"
                      gap={2}
                      m={0}
                      p={0}
                      listStyleType="none"
                    >
                      {cautions.map((caution, index) => (
                        <ListItem key={index}>
                          <Tag colorScheme="red">
                            <TagLabel textTransform="uppercase">
                              {caution}
                            </TagLabel>
                          </Tag>
                        </ListItem>
                      ))}
                    </UnorderedList>
                  </Box>
                )}

                {totalNutrients && (
                  <Box mb={4}>
                    <Text mb={2}>Total Nutrients:</Text>
                    <Box display="flex" flexWrap="wrap" gap={2}>
                      {Object.entries(totalNutrients || {}).map(
                        ([key, value]) => (
                          <Tag key={key} colorScheme="white">
                            <TagLabel>
                              {key}: {value.quantity.toFixed(0)} {value.unit}
                            </TagLabel>
                          </Tag>
                        )
                      )}
                    </Box>
                  </Box>
                )}
              </GridItem>
            </Grid>
          </CardBody>
        </Card>
      </Container>
    </Box>
  );
};
